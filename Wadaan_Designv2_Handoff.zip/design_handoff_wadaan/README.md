# Handoff: Wadaan Digital Archive

## Overview
A single-page archive/memorial website for **Wadaan – The Web Development Network**, a web design and development company active from April 2004 to 2007 in Västerås, Sweden. The site presents recovered content from the Internet Archive Wayback Machine as a curated digital specimen — part archive, part design artifact.

## About the Design Files
`Wadaan.dc.html` is a **high-fidelity design reference** built in HTML. It is not production-ready code to ship directly. The task is to **recreate this design in your target codebase** (React, Next.js, Vue, plain HTML, etc.) using its established patterns and conventions, while matching the visual output as closely as possible.

## Fidelity
**High-fidelity.** All colors, typography, spacing, layout structure, and content are final. Implement pixel-perfectly.

---

## Page Structure

The page is a single scrolling document with five numbered exhibit sections, a sticky navigation bar, a full-bleed dark hero, and a footer. Max content width is **1200px**, centered, with **48px horizontal padding**.

---

## Design Tokens

### Colors
| Token | Hex | Usage |
|---|---|---|
| `bg-base` | `#0b0a08` | Page background, hero |
| `bg-surface` | `#141210` | Cards, cells, panels |
| `bg-surface-alt` | `#0e0d0b` | Tech stack tags |
| `bg-archive-bar` | `#1a0800` | Archive notice bar |
| `border-default` | `#1e1c18` | Section dividers, borders |
| `border-card` | `#2a2825` | Cell/card borders |
| `text-primary` | `#f0ede6` | Main body text, headings |
| `text-muted` | `#8a8278` | Body paragraphs |
| `text-subtle` | `#6a6258` | Secondary labels, cell names |
| `text-dim` | `#4a4840` | Navigation links, list items |
| `text-ghost` | `#3a3830` | Footer text |
| `accent-amber` | `#e8a000` | Primary accent — nav underline, section labels, visitor counter |
| `accent-amber-dim` | `#e8a00060` | Muted amber (URLs, ghost elements) |
| `accent-red` | `#ff3300` | Archive bar border + badge |
| `accent-red-text` | `#ff6633` | Archive bar text |
| `cat-ecommerce` | `#e8a000` | E-Commerce cell top border |
| `cat-static` | `#4dffb4` | Static cell top border |
| `cat-realestate` | `#4d9fff` | Real Estate cell top border |
| `cat-cms` | `#ff6b6b` | CMS cell top border |
| `cat-later` | `#c084fc` | Later Projects cell top border |
| `footer-bg` | `#070605` | Footer background |

### Typography
| Role | Font | Size | Weight | Letter-spacing | Notes |
|---|---|---|---|---|---|
| Display / Hero | Bebas Neue | clamp(96px, 18vw, 220px) | 400 | 4px | "WADAAN" hero title |
| Section headings | Bebas Neue | 64px | 400 | 2px | e.g. "CLIENT ELEMENTS", "TRANSMISSIONS" |
| Section numbers (ghost) | Bebas Neue | 72px | 400 | 2px | `color: #1a1815` — decorative |
| Exhibit sub-heads | Bebas Neue | 24px | 400 | 1px | News post titles |
| Cell codes | Bebas Neue | 26px | 400 | 1px | 3-letter periodic table codes |
| Ghost year | Bebas Neue | 64px | 400 | 2px | `color: #2a2825` |
| Footer wordmark | Bebas Neue | 32px | 400 | 4px | |
| Body editorial | Cormorant Garamond | 18px | 300 | 0 | About text, blog body |
| Blockquote | Cormorant Garamond | 21px | 300 italic | 0 | |
| All labels / UI / data | IBM Plex Mono | 10px | 400 | varies | Exhibit labels, nav, timeline |
| Cell names | IBM Plex Mono | 6.5px | 400 | 0 | Below element codes in grid |
| Cell numbers | IBM Plex Mono | 7px | 400 | 0 | Top-right of each cell |
| Archive bar | IBM Plex Mono | 10px | 400 | 1px | |
| Nav links | IBM Plex Mono | 10px | 400 | 3px | Uppercase |

### Spacing
- Page horizontal padding: `48px`
- Hero top padding: `64px`
- Section vertical padding: `72px 0 56px`
- Card/cell inner padding: `8px 6px`
- Content gap (two-col): `48px`
- Grid gap (periodic table): `3px`
- Stack tag gap: `6px`

### Borders & Radius
- All borders: `1px solid` with color from token table above
- Category accent: `2px solid` top border on periodic table cells
- Nav bottom: `2px solid #e8a000`
- Footer top: `2px solid #e8a000`
- No border-radius anywhere — intentionally sharp/brutalist

---

## Sections

### Archive Notice Bar (top, full-width, not sticky)
- Background: `#1a0800`, border-bottom: `1px solid #ff3300`
- Padding: `7px 32px`
- Left: red badge `[ARCHIVED]` (`background: #ff3300`, `color: #fff`, `padding: 1px 6px`, `font-size: 9px`, `letter-spacing: 2px`)
- Centre text: `color: #cc4400`
- Right: catalog code `W-2004`, `color: #441100`, `letter-spacing: 3px`

### Hero (full-width)
- Background: `#0b0a08`, bottom border: `1px solid #1e1c18`
- Padding: `64px 48px 48px`
- Ghost background grid: CSS `background-image` with `rgba(232,160,0,0.03)` lines, `96px` grid size
- Ghost year: absolute positioned `right: -20px`, `top: 50%`, `translateY(-50%)`, Bebas Neue `320px`, `rgba(232,160,0,0.04)`
- Amber accent bar: `width: 48px`, `height: 2px`, `background: #e8a000`, `margin-bottom: 32px`
- Catalog label above title: IBM Plex Mono `10px`, `color: #e8a000`, `letter-spacing: 6px`, `opacity: 0.7`
- Title "WADAAN": Bebas Neue `clamp(96px, 18vw, 220px)`, `color: #f0ede6`, `letter-spacing: 4px`, `line-height: 0.85`
- Tagline row: separated by `border-top: 1px solid #2a2825`, `margin-top: 24px`
  - Left: IBM Plex Mono `11px`, `color: #6a6258`, `letter-spacing: 4px`, `text-transform: uppercase` + italic Cormorant Garamond `18px`, `color: #e8a000`
  - Right: Ghost year "2004–2007" in Bebas Neue `64px`, `color: #2a2825` + subtitle `9px` IBM Plex Mono `color: #3a3830`

### Sticky Navigation
- `position: sticky; top: 0; z-index: 100`
- Background: `rgba(11,10,8,0.97)`, `backdrop-filter: blur(12px)`
- Border-bottom: `2px solid #e8a000`
- Height: `48px`, padding `0 48px`
- Left: "W" in Bebas Neue `20px`, `color: #e8a000`, `letter-spacing: 4px`
- Right: 5 links — IBM Plex Mono `10px`, `color: #4a4840`, `letter-spacing: 3px`, uppercase
  - "01 / About", "02 / Portfolio", "03 / News", "04 / Products", "05 / Contact"

### Section Layout Pattern (all 5 sections use this)
Each section has:
1. A **label row**: flex row with a large ghost section number (`color: #1a1815`, Bebas Neue `72px`) on the left (width `120px`, `border-right: 1px solid #1e1c18`), and a label + amber gradient rule on the right
2. A **content row**: same `120px` left gutter with right border, content indented `32px` from that

### Exhibit 01 — About
**Two-column layout**: main text (flex: 1) + right column (width `280px`)

**Left column:**
- H2: Bebas Neue `64px`, `letter-spacing: 2px`, `line-height: 0.9` — "WHO WE WERE"
- 2× body paragraphs: Cormorant Garamond `18px`, `font-weight: 300`, `color: #a09888`, `line-height: 1.85`
- Blockquote: `border-left: 2px solid #e8a000`, `background: #141210`, `padding: 16px 24px`
  - Text: Cormorant Garamond `21px` italic, `color: #d0c8b8`, `line-height: 1.65`
  - Cite: IBM Plex Mono `9px`, `color: #e8a000`, `letter-spacing: 2px`

**Right column:**

*Timeline:*
- Label: IBM Plex Mono `9px`, `color: #e8a000`, `letter-spacing: 4px`
- Each row: flex, `padding: 12px 0`, `border-bottom: 1px solid #1a1815`
- Date: IBM Plex Mono `9px`, `color: #e8a000`, `width: 60px`
- Text: IBM Plex Mono `10px`, `color: #6a6258`
- Rows: APR 2004, MAR 2005, APR 2005, LATE 2005, 2006, 2007

*Services list:*
- Label + 11 items in IBM Plex Mono `10px`, `color: #4a4840`, `line-height: 2.1`

### Exhibit 02 — Portfolio (Periodic Table)
**"CLIENT ELEMENTS"** heading + description paragraph.

**Legend:** 5 color-coded items, each a `12px × 2px` swatch + IBM Plex Mono `9px` label.

**Grid:** `display: grid; grid-template-columns: repeat(7, 1fr); gap: 3px`
- 49 cells total, 7 columns × 7 rows
- Each cell: `height: 108px`, `padding: 8px 6px`, `position: relative`
- Cell number: IBM Plex Mono `7px`, `position: absolute; top: 6px; right: 6px`, color = category accent at 56% opacity
- Element code: Bebas Neue `26px`, `color: #f0ede6`, centered vertically (flex)
- Client name: IBM Plex Mono `6.5px`, `color: #6a6258`, centered, `line-height: 1.4`
- Top border: `2px solid [category color]`
- Background varies by category (slight tint):
  - E-Commerce: `#141210`
  - Static: `#101410`
  - Real Estate: `#0e1018`
  - CMS: `#180e0e`
  - Later: `#130e18`

**All 49 clients with their codes:**

| # | Code | Name | Category |
|---|---|---|---|
| 01 | SLP | Silver Lake Publications | E-Commerce |
| 02 | Z9P | Zone 9 Plants | E-Commerce |
| 03 | ANS | Angel Stop | E-Commerce |
| 04 | SPM | The Silver Penny Mall | E-Commerce |
| 05 | STR | Structured Style | E-Commerce |
| 06 | BLU | Blue Lapis | E-Commerce |
| 07 | FXW | Flexxware Golf | E-Commerce |
| 08 | BJS | The Beef Jerky Shop | E-Commerce |
| 09 | TXP | The Texas Poker Supply | E-Commerce |
| 10 | FLT | Florida Tickets | E-Commerce |
| 11 | AOW | A One Watches | E-Commerce |
| 12 | NGC | Nintendo SystemsGCN | E-Commerce |
| 13 | SSL | Sounds Sublime Shop | E-Commerce |
| 14 | BAK | 1-800 Bakery | E-Commerce |
| 15 | ETC | Empress Tea Company | E-Commerce |
| 16 | AUC | Audio Cubes | E-Commerce |
| 17 | NEU | Neustrafe | E-Commerce |
| 18 | EFK | Eflein Kosmetik | E-Commerce |
| 19 | TMP | Today's Market Place | E-Commerce |
| 20 | LJN | Lori Jean | E-Commerce |
| 21 | WCD | World of CDs | E-Commerce |
| 22 | AOS | A One Stones | Static |
| 23 | ARY | Aryana Site | Static |
| 24 | ISI | The Site for Islamic Info | Static |
| 25 | NWF | NWFP Wildlife Department | Static |
| 26 | BLV | The Boulevard Condos | Static |
| 27 | PHS | Plastic Hand Surgery | Static |
| 28 | DPK | DPK Online | Static |
| 29 | RLS | RL Spring | Static |
| 30 | FRA | Frontier Archaeology | Static |
| 31 | ROM | Rent O Maha | Real Estate |
| 32 | RHN | Roatan Honduras Real Estate | Real Estate |
| 33 | RCA | Roatan Caribbean | Real Estate |
| 34 | MIO | MIO Watch | CMS |
| 35 | PTF | The Pashtun Foundation | CMS |
| 36 | UOT | University of Ottawa Canada | CMS |
| 37 | GAL | Gallob | CMS |
| 38 | NCA | News Central Asia | CMS |
| 39 | WAS | Water and Stone | CMS |
| 40 | NWH | North West HIV Physicians Network | CMS |
| 41 | ATJ | Afghan Tribe Jewelry | CMS |
| 42 | COU | Chill Out BU | CMS |
| 43 | SOL | Solar Weekend | CMS |
| 44 | APC | Airline Pilot Central | CMS |
| 45 | ZLU | Zelda Universe | CMS |
| 46 | LVN | Leather Villa New York | Later 2006 |
| 47 | MWB | Midwest Bargains | Later 2006 |
| 48 | XFP | Exclusive FCP | Later 2006 |
| 49 | WOC | World of CDs (CRELoaded) | Later 2006 |

### Exhibit 03 — News & Blog
**"TRANSMISSIONS"** heading.

Each post: `display: grid; grid-template-columns: 140px 1fr; gap: 32px; border-bottom: 1px solid #1a1815; padding: 24px 0`

- Left: IBM Plex Mono `9px`, `color: #e8a000` — date + divider `———` + category tag in `color: #3a3830`
- Right:
  - Title: Bebas Neue `24px`, `color: #f0ede6`, `letter-spacing: 1px`, `margin-bottom: 10px`
  - Body: Cormorant Garamond `16px`, `font-weight: 300`, `color: #8a8278`, `line-height: 1.75`
  - URL (where applicable): IBM Plex Mono `9px`, `color: #e8a00060`

**8 posts:** Welcome (12 Apr 2004), Texas Poker Supply (25 Mar 2005), Florida Tickets (01 Apr 2005), IBM Patents (2005), Leather Villa NY (2006), Midwest Bargains (2006), Exclusive FCP (2006), World of CDs (2006 — combined)

### Exhibit 04 — Products
**"STUFF FOR SALE"** heading.

4-column grid of product category panels: `grid-template-columns: 1fr 1fr 1fr 1fr; gap: 3px`
- Each panel: `background: #141210`, `border: 1px solid #2a2825`, `padding: 20px 16px`
- Category label: IBM Plex Mono `9px`, `color: #e8a000`, `letter-spacing: 3px`, amber bottom border
- List items: IBM Plex Mono `10px`, `color: #4a4840`, `line-height: 2.1`

Categories: FULL SITES, TEMPLATES, LOGOS, MODULES

**Technology Stack:**
- Label: IBM Plex Mono `9px`, `color: #e8a000`, `letter-spacing: 4px`
- Tags: `display: flex; flex-wrap: wrap; gap: 6px`
- Each tag: IBM Plex Mono `10px`, `color: #3a3830`, `border: 1px solid #1e1c18`, `padding: 4px 10px`, `background: #0e0d0b`
- W-CMS special: `color: #e8a000`, `border: 1px solid #e8a00030`, `background: #1a1408`

21 technologies: PHP, MySQL, HTML/CSS, JavaScript, Flash, Photoshop, Fireworks, osCommerce, ZenCart, osCMax, CRELoaded, X-Cart, CubeCart, Mambo/Joomla, Drupal, Xoops, Plone, Typo3, W-CMS, PHP Auction, Open Reality

### Exhibit 05 — Contact
**"GET IN TOUCH"** heading + italic disclaimer.

2×2 contact grid (`max-width: 640px`): `grid-template-columns: 1fr 1fr; gap: 3px`
- Each cell: `background: #141210`, `border: 1px solid #2a2825`, `padding: 16px 20px`
- Label: IBM Plex Mono `8px`, `color: #e8a000`, `letter-spacing: 2px`
- Value: IBM Plex Mono `11px`, `color: #c0b8a8` (or `#e8a00070` for archived fields)

Fields: ORGANISATION, LOCATION, EMAIL [ARCHIVED], PHONE [ARCHIVED]

**Visitor Log widget:**
- `display: inline-flex`, `border: 1px solid #2a2825`, `padding: 16px 24px`, `background: #0e0d0b`
- Counter: Bebas Neue `48px`, `color: #e8a000`, `letter-spacing: 4px` — value: **4,821**
- Label: IBM Plex Mono `8px`, `color: #e8a000`
- Description: IBM Plex Mono `10px`, `color: #2a2825`

### Footer
- Background: `#070605`, `border-top: 2px solid #e8a000`, `padding: 32px 48px`
- Left: "WADAAN" Bebas Neue `32px`, `color: #e8a000` + metadata IBM Plex Mono `9px`, `color: #2a2825`
- Right: IBM Plex Mono `9px`, `color: #2a2825`, right-aligned, `line-height: 1.8`

---

## Interactions & Behavior

- **Sticky nav**: becomes visible as user scrolls past the hero. `backdrop-filter: blur(12px)` for glass effect.
- **Anchor navigation**: all 5 nav links scroll to their respective `id` on the page (`#about`, `#portfolio`, `#news`, `#products`, `#contact`).
- **Links**: hover state = `text-decoration: underline`. External URLs in news section open in new tab.
- **No animations** — the design is intentionally static and archival.

---

## Responsive Behavior
The current design targets desktop (1200px+ content width). For responsive implementation:
- Below `1024px`: collapse the `120px` left gutter / section number column
- Below `768px`: periodic table should reduce to 4 columns, then 3
- Below `480px`: periodic table = 2 columns; hero title scales down via `clamp()`

---

## Assets & Fonts
All fonts are loaded from **Google Fonts CDN**:
```
https://fonts.googleapis.com/css2?family=Bebas+Neue&family=IBM+Plex+Mono:ital,wght@0,300;0,400;0,500;1,300&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&display=swap
```
No external images or icons — the design uses pure CSS and text.

---

## Files
| File | Description |
|---|---|
| `Wadaan.dc.html` | Full high-fidelity design reference — single-page HTML |
| `README.md` | This document |
